# Problem Set 8: Motion History Images

Template code for PS8.
